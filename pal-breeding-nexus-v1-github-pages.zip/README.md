# Pal Breeding Nexus

A mobile-friendly, installable Pal breeding calculator prototype.

## GitHub Pages

1. Upload every file and the `icons` folder to the repository root.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select **main** and **/(root)**, then save.
5. The site will appear at `https://rivolegacy.github.io/pal-breeding-nexus/`.

## Install on iPhone

Open the live site in Safari, tap **Share**, then **Add to Home Screen**.

## Note

This is a fan-made prototype and is not affiliated with Pocketpair or Palworld.gg. The included breeding data is a demonstration subset and should be replaced with a verified current dataset before presenting it as complete.
